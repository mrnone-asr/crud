import React, { useState, useEffect } from "react";

const CrudComponent = () => {
  const [items, setItems] = useState([]);
  const [name, setName] = useState("");
  const [editIndex, setEditIndex] = useState(-1);

  /*   const apiKey = "64f868efe99febf370d6701d";

  useEffect(() => {
    fetch("https://dummyapi.io/data/v1/", {
      headers: {
        Authorization: `Bearer ${apiKey}`, 
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setItems(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, [apiKey]); */

  const handleAddItem = () => {
    if (name) {
      setItems([...items, { name, id: Date.now() }]);
      setName("");
    }
  };

  const handleDeleteItem = (id) => {
    const updatedItems = items.filter((item) => item.id !== id);
    setItems(updatedItems);
  };

  const handleEditItem = (id) => {
    const editItem = items.find((item) => item.id === id);
    if (editItem) {
      setName(editItem.name);
      setEditIndex(id);
    }
  };

  const handleUpdateItem = () => {
    if (name && editIndex !== -1) {
      const updatedItems = items.map((item) =>
        item.id === editIndex ? { ...item, name } : item
      );
      setItems(updatedItems);
      setName("");
      setEditIndex(-1);
    }
  };

  return (
    <div>
      <h2>CRUD Component</h2>

      {/* List of items */}
      <div className="box" style={{ height: "200px", overflowY: "scroll" }}>
        <ul>
          {items.map((item) => (
            <li key={item.id}>
              {editIndex === item.id ? (
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              ) : (
                item.name
              )}
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => handleEditItem(item.id)}
              >
                Edit
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => handleDeleteItem(item.id)}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Add a new item */}
      <div className="input-group input-group-lg">
        <input
          type="text"
          className="form-control"
          aria-label="Sizing example input"
          aria-describedby="inputGroup-sizing-lg"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter name"
        />
        <button
          type="button"
          className="btn btn-success"
          onClick={() =>
            editIndex === -1 ? handleAddItem() : handleUpdateItem()
          }
        >
          {editIndex === -1 ? "Add" : "Update"}
        </button>
      </div>
    </div>
  );
};

export default CrudComponent;

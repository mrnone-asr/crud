import React, { useState } from "react";
import Crud from "./crud";

export default function Home() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const [loggedIn, setLoggedIn] = useState(false);

  const validateForm = () => {
    const newErrors = { ...errors };
    if (formData.email !== "aman@gmail" || formData.password !== "1234") {
      newErrors.email = newErrors.password = "Incorrect email or password";
    } else {
      newErrors.email = newErrors.password = "";
      setLoggedIn(true);
    }
    setErrors(newErrors);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    validateForm();
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div className="container">
      <div className="heading">
        <h1>Welcome</h1>
      </div>
      {!loggedIn ? (
        <form onSubmit={handleSubmit}>
          <h1>Login</h1>
          <div className="mb-3">
            <label htmlFor="exampleInputEmail1" className="form-label">
              Email address
            </label>
            <input
              type="email"
              className={`form-control ${errors.email && "is-invalid"}`}
              id="exampleInputEmail1"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputPassword1" className="form-label">
              Password
            </label>
            <input
              type="password"
              className={`form-control ${errors.password && "is-invalid"}`}
              id="exampleInputPassword1"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
            />
            {errors.password && (
              <div className="invalid-feedback">{errors.password}</div>
            )}
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      ) : (
        <Crud />
      )}
    </div>
  );
}
